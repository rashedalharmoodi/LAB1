#include "student.h"

int smallest(int array[5],int length) {
   int i, min;
     printf("Enter the length of the array: ");
      scanf("%d", &length);//get input from user for length 
      for(i=0; i<length; i++){
    printf("Enter element %d: ",i+1);//enter elements for array
    scanf("%d", &array[i]);
    }
    min = array[0];
    
      for(i=0; i<length; i++){//iterate for loop from first index of array
    if(min>array[i])
    {
        min=array[i];
    }
    }
   printf("\nSmallest elements is: %d",min);
getch();//display result on the screen
    return 0;
}
  
  


double mean(int array[20], int length)
 {     
        double avg=0,sum=0;
        int i;
        printf("Enter the numbers of average: ");
    scanf("%d",&length);
    
    printf("Enter the numbers: \n");
    for(i=1; i<=length; i++)
    {//loop for get input numbers
        scanf("%d", &array[i]);
    
    }
        for(i=1; i<=length; i++){
        sum=sum+array[i];//loop for calculating sum
        avg=sum/length;//calculate average
    }
           
  return 0;
}

void swap(int *a, int *b) {
     int x, y, temp;
      printf("Enter the value of x and y\n");
   scanf("%d%d", &x, &y);
    printf("Before Swapping\nx = %d\ny = %d\n", x, y);
 
   a = &x;
   b = &y;
 
   temp = *b;
   *b = *a;
   *a = temp;
 
   printf("After Swapping\nx = %d\ny = %d\n", x, y);
 

}

void squaredPrimes(int array[],int length){
     
     int argc, I;
    
      printf("Enter an odd integer n between 3 and 15: ");
    scanf("%d", &length);

    printf("Enter an initial value i: ");
    scanf("%d", &I);
    int arr[length][length];
    int k = 1;
    int i = length / 2 + 1;
    int j = length / 2 + 1;
    while(k < length) {
            int s;

            for(s = 0; s < k; s++, i++, I++)
                    arr[i][j] = IsPrime(I) ? I : -1;
            for(s = 0; s < k; s++, j--, k++)
                    arr[i][j] = IsPrime(I) ? : -1;
            k++;
            for(s = 0; s < k; s++, i--, I++)
                    arr[i][j] = IsPrime(I) ? I : -1;
            for(s = 0; s < k; s++, j++, I++)
                    arr[i][j] = IsPrime(I) ? I :-1;
            arr[i][j] = IsPrime(I) ? I : -1;
            k++;

            if(IsPrime(i) == 1) {
                printf("output", i);
            } else {
                    printf("***");
            }
    }
    
}
int IsPrime(int n) {
    int i, count = 0;

    for(i = 1; i <= n; i++) {
            if((n % i) == 0) count++;
    }
}

void sort(int array[20],int length){
     int n, i, j, tmp;
     
     printf("Input the size of array : ");
    scanf("%d", &length);

       printf("Input %d elements in the array :\n",length);
       for(i=0;i<length;i++)
            {
	      printf("element - %d : ",i);
	      scanf("%d",&array[i]);
	    }
	    
	    for(i=0; i<length; i++)
    {
        for(j=i+1; j<length; j++)
        {
            if(array[j] <array[i])
            {
                tmp = array[i];
                array[i] = array[j];
                array[j] = tmp;
            }
        }
    }
    printf("\nElements of array in sorted ascending order:\n");
    for(i=0; i<length; i++)
    {
        printf("%d  ", array[i]);
    }
	        printf("\n\n");
}


void negate_fibonacci(int fibarray[100],int fibLength){
     int i;
      printf("How many Fibonacci numbers do you want?: ");
    scanf("%d",&fibLength);
     fibarray[0] = 0;
    fibarray[1] = 1;

    for(i = 2; i < fibLength; i++)
        fibarray[i] = fibarray[i-1] + fibarray[i-2];

    for (i = 1; i < fibLength; i++)
        printf("%d: %d\n", i, fibarray[i]);

    
}



